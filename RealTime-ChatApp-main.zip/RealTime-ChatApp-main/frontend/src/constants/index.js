export const THEMES = [
    "light",
    "dark"
  ];
  